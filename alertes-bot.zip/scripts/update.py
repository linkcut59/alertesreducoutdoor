#!/usr/bin/env python3
"""Relève les grosses baisses de prix, met à jour alerts.json et poste sur Telegram."""
import html
import json
import os
import re
import sys
import time
from datetime import date
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCES_FILE = os.path.join(ROOT, "sources.json")
OUTPUT_FILE = os.path.join(ROOT, os.environ.get("OUTPUT_FILE", "docs/data/alerts.json"))

MIN_DISCOUNT = int(os.environ.get("MIN_DISCOUNT", "30"))  # % minimum pour être retenu
MAX_DISCOUNT = 90  # au-dessus, c'est presque sûrement une erreur de lecture
POST_LIMIT = int(os.environ.get("POST_LIMIT", "10"))  # messages Telegram max par passage
MAX_KEEP = 100  # offres gardées sur le site
DRY_RUN = os.environ.get("DRY_RUN", "").strip().lower() in ("1", "true", "yes")

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9",
}

PRICE_RE = re.compile(r"(\d[\d\s\u00a0\u202f]*(?:[.,]\d{1,2})?)\s*(?:€|EUR)")
OLD_PRICE_SELECTOR = (
    "s, del, strike, [class*=old], [class*=strike], [class*=before], "
    "[class*=barr], [class*=original], [class*=initial], [class*=was]"
)


def to_float(raw):
    s = re.sub(r"[\s\u00a0\u202f]", "", raw)
    if "," in s and "." in s:
        s = s.replace(".", "")
    s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def find_prices(text):
    out = []
    for m in PRICE_RE.finditer(text):
        v = to_float(m.group(1))
        if v is not None and v > 0:
            out.append(v)
    return out


def best_image(node, base_url):
    img = node.find("img")
    if not img:
        return None
    for attr in ("data-src", "data-original", "data-lazy-src", "src"):
        v = img.get(attr)
        if v and not v.startswith("data:"):
            return urljoin(base_url, v)
    srcset = img.get("srcset") or img.get("data-srcset")
    if srcset:
        return urljoin(base_url, srcset.split(",")[0].strip().split(" ")[0])
    return None


def best_title(node, anchor):
    img = node.find("img")
    if img and img.get("alt") and len(img["alt"].strip()) > 5:
        return img["alt"].strip()
    for tag in ("h2", "h3", "h4", "h5"):
        h = node.find(tag)
        if h and h.get_text(strip=True):
            return h.get_text(" ", strip=True)
    if anchor.get("title"):
        return anchor["title"].strip()
    text = PRICE_RE.sub("", anchor.get_text(" ", strip=True))
    return re.sub(r"\s+", " ", text).strip()[:120]


def parse_page(page_html, base_url, shop):
    """Cherche des cartes produit contenant un prix barré et un prix actuel."""
    soup = BeautifulSoup(page_html, "html.parser")
    deals = {}
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.startswith(("#", "javascript:", "mailto:", "tel:")):
            continue
        card = None
        node = a
        for _ in range(5):
            if node is None or node.name in ("body", "html"):
                break
            hrefs = {x["href"] for x in node.find_all("a", href=True)}
            if len(hrefs) > 3:
                break  # conteneur trop grand : plusieurs produits mélangés
            if len(set(find_prices(node.get_text(" ", strip=True)))) >= 2:
                card = node
                break
            node = node.parent
        if card is None:
            continue
        node = card

        prices = sorted(set(find_prices(node.get_text(" ", strip=True))))
        if len(prices) < 2:
            continue

        old = None
        for el in node.select(OLD_PRICE_SELECTOR):
            found = find_prices(el.get_text(" ", strip=True))
            if found:
                old = max(found)
                break
        if old is None:
            old = prices[-1]
        lower = [p for p in prices if p < old]
        if not lower:
            continue
        price = max(lower)  # on ignore les montants du type « vous économisez X € »

        pct = round((1 - price / old) * 100)
        if price < 5 or pct < MIN_DISCOUNT or pct > MAX_DISCOUNT:
            continue

        url = urljoin(base_url, href)
        title = best_title(node, a)
        if len(title) < 4:
            continue
        deals[url] = {
            "title": title,
            "shop": shop,
            "price": price,
            "old_price": old,
            "discount": pct,
            "url": url,
            "image": best_image(node, base_url),
        }
    return list(deals.values())


def load_sources():
    try:
        with open(SOURCES_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError) as e:
        print(f"sources.json illisible : {e}")
        return []
    return [s for s in data if str(s.get("url", "")).startswith("http")]


def load_existing():
    try:
        with open(OUTPUT_FILE, encoding="utf-8") as f:
            data = json.load(f)
        # on ignore les offres d'exemple (elles n'ont pas été créées par le bot)
        return [d for d in data if isinstance(d, dict) and d.get("src") == "bot"]
    except (OSError, ValueError):
        return []


def euro(v):
    return f"{v:,.2f}".replace(",", " ").replace(".", ",") + " €"


def send_telegram(d):
    text = (
        f"🔥 <b>-{d['discount']} %</b> · {html.escape(d['shop'])}\n"
        f"{html.escape(d['title'])}\n"
        f"<b>{euro(d['price'])}</b> <s>{euro(d['old_price'])}</s>\n"
        f'<a href="{html.escape(d["url"], quote=True)}">Voir l\'offre</a>'
    )
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{TOKEN}/sendMessage",
            json={
                "chat_id": CHAT_ID,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": False,
            },
            timeout=30,
        )
        if r.ok:
            return True
        print(f"  Telegram a refusé le message : {r.status_code} {r.json().get('description', '')}")
    except requests.RequestException as e:
        print(f"  Erreur réseau Telegram : {type(e).__name__}")
    return False


def main():
    sources = load_sources()
    if not sources:
        print("Aucune source valide dans sources.json (les liens doivent commencer par http).")
        return 1

    current = []
    for src in sources:
        shop, url = src.get("shop", "?"), src["url"]
        try:
            r = requests.get(url, headers=HEADERS, timeout=30)
        except requests.RequestException as e:
            print(f"[{shop}] échec réseau : {type(e).__name__}")
            continue
        if r.status_code != 200:
            print(f"[{shop}] HTTP {r.status_code} sur {url}")
            continue
        found = parse_page(r.text, url, shop)
        print(f"[{shop}] {len(found)} offre(s) à -{MIN_DISCOUNT} % ou plus ({len(r.text)} caractères reçus)")
        current.extend(found)

    if not current:
        print("Aucune offre trouvée : alerts.json est laissé tel quel.")
        return 1

    # Fusion avec l'existant : on garde la date de 1re apparition et l'état « posté »
    previous = {d["url"]: d for d in load_existing()}
    today = date.today().isoformat()
    merged = []
    for d in current:
        old = previous.get(d["url"])
        if old and abs(old.get("price", 0) - d["price"]) < 0.01:
            d["date"] = old.get("date", today)
            d["posted"] = bool(old.get("posted"))
        else:
            d["date"] = today
            d["posted"] = False
        d["src"] = "bot"
        merged.append(d)

    merged.sort(key=lambda x: (x["discount"], x["date"]), reverse=True)
    merged = merged[:MAX_KEEP]

    # Envoi Telegram (les meilleures remises d'abord)
    todo = [d for d in merged if not d["posted"]]
    print(f"{len(todo)} offre(s) pas encore postée(s).")
    if DRY_RUN:
        print("Mode test : rien n'est envoyé sur Telegram.")
    elif not TOKEN or not CHAT_ID:
        print("Secrets Telegram absents : rien n'est envoyé.")
    else:
        sent = 0
        for d in todo[:POST_LIMIT]:
            if send_telegram(d):
                d["posted"] = True
                sent += 1
            time.sleep(3.5)  # Telegram limite le débit sur un canal
        print(f"{sent} message(s) envoyé(s).")

    merged.sort(key=lambda x: x["date"], reverse=True)
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)
    print(f"{len(merged)} offre(s) écrites dans {os.path.relpath(OUTPUT_FILE, ROOT)}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
